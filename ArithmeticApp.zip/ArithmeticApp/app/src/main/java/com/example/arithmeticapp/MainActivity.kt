package com.example.arithmeticapp

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    // UI Elements
    private lateinit var etNumber1: EditText
    private lateinit var etNumber2: EditText
    private lateinit var btnAdd: Button
    private lateinit var btnSubtract: Button
    private lateinit var btnMultiply: Button
    private lateinit var btnDivide: Button
    private lateinit var btnClear: Button
    private lateinit var tvResult: TextView
    private lateinit var tvOperation: TextView
    private lateinit var tvHistory: TextView
    private lateinit var scrollHistory: ScrollView

    private val historyList = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize views
        etNumber1     = findViewById(R.id.etNumber1)
        etNumber2     = findViewById(R.id.etNumber2)
        btnAdd        = findViewById(R.id.btnAdd)
        btnSubtract   = findViewById(R.id.btnSubtract)
        btnMultiply   = findViewById(R.id.btnMultiply)
        btnDivide     = findViewById(R.id.btnDivide)
        btnClear      = findViewById(R.id.btnClear)
        tvResult      = findViewById(R.id.tvResult)
        tvOperation   = findViewById(R.id.tvOperation)
        tvHistory     = findViewById(R.id.tvHistory)
        scrollHistory = findViewById(R.id.scrollHistory)

        // Set button click listeners
        btnAdd.setOnClickListener      { performOperation(Operation.ADD) }
        btnSubtract.setOnClickListener { performOperation(Operation.SUBTRACT) }
        btnMultiply.setOnClickListener { performOperation(Operation.MULTIPLY) }
        btnDivide.setOnClickListener   { performOperation(Operation.DIVIDE) }
        btnClear.setOnClickListener    { clearAll() }
    }

    // ── Arithmetic Functions ──────────────────────────────────────────────────

    private fun add(a: Double, b: Double): Double = a + b

    private fun subtract(a: Double, b: Double): Double = a - b

    private fun multiply(a: Double, b: Double): Double = a * b

    private fun divide(a: Double, b: Double): Double {
        if (b == 0.0) throw ArithmeticException("Cannot divide by zero")
        return a / b
    }

    // ── Operation Dispatcher ──────────────────────────────────────────────────

    private enum class Operation { ADD, SUBTRACT, MULTIPLY, DIVIDE }

    private fun performOperation(op: Operation) {
        val input1 = etNumber1.text.toString().trim()
        val input2 = etNumber2.text.toString().trim()

        // Validate inputs
        if (input1.isEmpty() || input2.isEmpty()) {
            showError("Please enter both numbers")
            return
        }

        val num1 = input1.toDoubleOrNull()
        val num2 = input2.toDoubleOrNull()

        if (num1 == null || num2 == null) {
            showError("Invalid number format")
            return
        }

        try {
            val (result, symbol) = when (op) {
                Operation.ADD      -> Pair(add(num1, num2),      "+")
                Operation.SUBTRACT -> Pair(subtract(num1, num2), "−")
                Operation.MULTIPLY -> Pair(multiply(num1, num2), "×")
                Operation.DIVIDE   -> Pair(divide(num1, num2),   "÷")
            }

            val formattedNum1 = formatNumber(num1)
            val formattedNum2 = formatNumber(num2)
            val formattedResult = formatNumber(result)

            val operationStr = "$formattedNum1  $symbol  $formattedNum2"
            val historyEntry = "$operationStr  =  $formattedResult"

            // Update UI
            tvOperation.text = operationStr
            tvResult.text = formattedResult
            tvResult.setTextColor(ContextCompat.getColor(this, R.color.result_success))

            // Add to history
            historyList.add(0, historyEntry)
            updateHistory()

        } catch (e: ArithmeticException) {
            showError(e.message ?: "Math error")
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /** Format: removes unnecessary trailing zeros */
    private fun formatNumber(value: Double): String {
        return if (value == value.toLong().toDouble()) {
            value.toLong().toString()
        } else {
            // Round to 8 significant decimal places
            "%.8f".format(value).trimEnd('0').trimEnd('.')
        }
    }

    private fun showError(message: String) {
        tvOperation.text = ""
        tvResult.text = message
        tvResult.setTextColor(ContextCompat.getColor(this, R.color.result_error))
    }

    private fun clearAll() {
        etNumber1.text.clear()
        etNumber2.text.clear()
        tvOperation.text = ""
        tvResult.text = "0"
        tvResult.setTextColor(ContextCompat.getColor(this, R.color.result_success))
        historyList.clear()
        updateHistory()
    }

    private fun updateHistory() {
        if (historyList.isEmpty()) {
            tvHistory.text = "No history yet"
            return
        }
        tvHistory.text = historyList.take(20).joinToString("\n\n")
        // Scroll to top to show latest entry
        scrollHistory.post { scrollHistory.smoothScrollTo(0, 0) }
    }
}
